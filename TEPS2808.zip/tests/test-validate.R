# tests/test-validate.R
# Krever testthat hvis dere vil kjøre formaliserte tester

if (requireNamespace("testthat", quietly = TRUE)) {
  source(file.path("R", "utils_selectors.R"))
  source(file.path("R", "validate_selectors.R"))
  cfg <- get_selectors_config("config/selectors.yaml")
  
  testthat::test_that("alle HTML-selectorer matcher noe på sample_url", {
    res <- validate_all(cfg, verbose = FALSE)
    # PDF-kilder er TRUE by design i valideringen (hopper over)
    testthat::expect_true(all(res))
  })
} else {
  message("Hint: install.packages('testthat') for å kjøre testene.")
}
