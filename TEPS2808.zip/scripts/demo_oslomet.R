# scripts/demo_oslomet.R
# Minimal kjøreeksempel

source("R/utils_selectors.R")
source("R/scrape_course_page.R")
source("R/scrape_pdf.R")
source("R/validate_selectors.R")

# 1) Les YAML
cfg <- get_selectors_config("config/selectors.yaml")

# 2) Valider selectors for Oslomet
validate_selectors(cfg, "oslomet")

# 3) Skrap en sample-side (bytt URL ved behov)
inst_key <- "oslomet"
url <- get_institution(cfg, inst_key)$sample_url

res <- scrape_course_url(url, cfg, inst_key)

# 4) Skriv til .txt for manuell sjekk
out_path <- file.path("out", sprintf("%s_sample.txt", inst_key))
dir.create("out", showWarnings = FALSE, recursive = TRUE)
lines <- c(sprintf("# %s", res$title), "", paste(res$sections, collapse = "\n\n---\n\n"))
con <- file(out_path, open = "wb"); writeBin(charToRaw(paste(lines, collapse="\n")), con); close(con)

message(sprintf("Skrevet: %s", normalizePath(out_path)))
