# R/scrape_course_page.R
# HTML-scraper som bruker selectors fra YAML

scrape_course_page <- function(page, cfg, inst_key) {
  if (!requireNamespace("rvest", quietly = TRUE)) {
    stop("Manglende pakke: rvest. Kjør install.packages('rvest')")
  }
  if (!requireNamespace("xml2", quietly = TRUE)) {
    stop("Manglende pakke: xml2. Kjør install.packages('xml2')")
  }
  if (!requireNamespace("stringr", quietly = TRUE)) {
    stop("Manglende pakke: stringr. Kjør install.packages('stringr')")
  }
  
  if (is_pdf_source(cfg, inst_key)) {
    stop("Dette er en PDF-kilde. Bruk scrape_pdf() i stedet.")
  }
  
  title_sel   <- get_sel(cfg, inst_key, "title")
  head_sel    <- get_sel(cfg, inst_key, "section_headers")
  body_sel    <- get_sel(cfg, inst_key, "section_bodies")
  
  title <- rvest::html_element(page, title_sel) |> rvest::html_text2()
  headers <- rvest::html_elements(page, head_sel) |> rvest::html_text2()
  bodies  <- rvest::html_elements(page, body_sel) |> rvest::html_text2()
  
  if (length(headers) != length(bodies)) {
    warning(sprintf("Mismatch headers(%d) vs bodies(%d) for %s", length(headers), length(bodies), inst_key))
  }
  
  sections <- mapply(function(h, b) sprintf("### %s\n\n%s", h, b), headers, bodies, USE.NAMES = FALSE)
  list(title = ifelse(is.na(title), "", title), sections = sections)
}

# Praktisk wrapper: ta URL direkte
scrape_course_url <- function(url, cfg, inst_key) {
  if (!requireNamespace("xml2", quietly = TRUE)) {
    stop("Manglende pakke: xml2. Kjør install.packages('xml2')")
  }
  page <- xml2::read_html(url)
  scrape_course_page(page, cfg, inst_key)
}
