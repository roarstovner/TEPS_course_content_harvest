# R/scrape_pdf.R
# Enkel PDF-scraper via pdftools

scrape_pdf <- function(url, out_txt_path = NULL) {
  if (!requireNamespace("pdftools", quietly = TRUE)) {
    stop("Manglende pakke: pdftools. Kjør install.packages('pdftools')")
  }
  tf <- tempfile(fileext = ".pdf")
  utils::download.file(url, tf, mode = "wb", quiet = TRUE)
  pages <- pdftools::pdf_text(tf)
  full <- paste(pages, collapse = "\n\n---PAGE---\n\n")
  if (!is.null(out_txt_path)) {
    con <- file(out_txt_path, open = "wb")
    on.exit(close(con), add = TRUE)
    writeBin(charToRaw(full), con)
  }
  full
}
