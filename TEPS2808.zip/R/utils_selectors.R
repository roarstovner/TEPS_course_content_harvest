# R/utils_selectors.R
# Hjelpefunksjoner for å lese YAML-selectors og gjøre oppslag per institusjon

get_selectors_config <- function(path = "config/selectors.yaml") {
  if (!requireNamespace("yaml", quietly = TRUE)) {
    stop("Manglende pakke: yaml. Kjør install.packages('yaml')")
  }
  yaml::read_yaml(path)
}

get_institution <- function(cfg, inst_key) {
  idx <- vapply(cfg$institutions, function(x) identical(x$key, inst_key), logical(1))
  if (!any(idx)) stop(sprintf("Ukjent institusjon: %s", inst_key))
  cfg$institutions[[which(idx)]]
}

get_sel <- function(cfg, inst_key, field) {
  inst <- get_institution(cfg, inst_key)
  inst$selectors[[field]]
}

is_pdf_source <- function(cfg, inst_key) {
  inst <- get_institution(cfg, inst_key)
  isTRUE(inst$selectors$pdf)
}
