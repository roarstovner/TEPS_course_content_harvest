# R/validate_selectors.R
# Validerer at selectors faktisk matcher noe på sample_url

validate_selectors <- function(cfg, inst_key, verbose = TRUE) {
  inst <- get_institution(cfg, inst_key)
  if (is_pdf_source(cfg, inst_key)) {
    if (verbose) message(sprintf("[%s] PDF-kilde – hopper over HTML-validering.", inst_key))
    return(TRUE)
  }
  if (!requireNamespace("xml2", quietly = TRUE)) {
    stop("Manglende pakke: xml2. Kjør install.packages('xml2')")
  }
  if (!requireNamespace("rvest", quietly = TRUE)) {
    stop("Manglende pakke: rvest. Kjør install.packages('rvest')")
  }
  page <- xml2::read_html(inst$sample_url)
  fields <- setdiff(names(inst$selectors), "pdf")
  ok_vec <- logical(length(fields))
  names(ok_vec) <- fields
  for (i in seq_along(fields)) {
    field <- fields[i]
    sel <- inst$selectors[[field]]
    if (is.null(sel) || !nzchar(sel)) {
      ok_vec[i] <- FALSE
      if (verbose) message(sprintf("[%s] %s: TOM SELECTOR", inst_key, field))
      next
    }
    nodes <- rvest::html_elements(page, sel)
    ok <- length(nodes) > 0
    ok_vec[i] <- ok
    if (verbose) message(sprintf("[%s] %s: %s (%s)", inst_key, field, if (ok) "OK" else "FAILET", sel))
  }
  all(ok_vec)
}

validate_all <- function(cfg, verbose = TRUE) {
  keys <- vapply(cfg$institutions, function(x) x$key, character(1))
  res <- vapply(keys, function(k) validate_selectors(cfg, k, verbose = verbose), logical(1))
  invisible(res)
}
